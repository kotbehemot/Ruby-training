class PostsController < ApplicationController
  skip_before_filter :login_required, :only => [:index]

  def index
    @posts = Post.all
  end

  def new
    @post = Post.new
  end

  def create
    @post = Post.new(params[:post])
    if @post.save
      redirect_to posts_url, :notice => "Successfully created post."
    else
      render :action => 'new'
    end
  end

  def edit
  end

  def update
    if @post.update_attributes(params[:post])
      redirect_to posts_url, :notice  => "Successfully updated post."
    else
      render :action => 'edit'
    end
  end

  protected

  def get_member_resources
    @post = Post.find(params[:id])
  end

end
